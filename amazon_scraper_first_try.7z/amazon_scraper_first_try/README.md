# Amazon Scraper First Try 

A simple amazon scraper to extract product details and prices from Amazon.com using Python Requests and Selectorlib. 

